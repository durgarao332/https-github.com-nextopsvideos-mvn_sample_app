package com.tericcabrel.bmi.utils;

public class Constants {
    public static String BMI_UNDERWEIGHT = "Underweight";
    public static String BMI_NORMAL = "Normal";
    public static String BMI_OVERWEIGHT = "Overweight";
    public static String BMI_OBESITY_CLASS_ONE = "Obesity class 1";
    public static String BMI_OBESITY_CLASS_TWO = "Obesity class 2";
    public static String BMI_OBESITY_CLASS_THREE = "Obesity class 3";
}
